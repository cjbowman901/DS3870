var arrEmployee;
$.getJSON("https://www.swollenhippo.com/getStaffByAPIKey.php?APIKey=DuffManSays,Phrasing!", function(result){
    console.log(result);
    arrEmployee = result;
    buildEmployeeCard();

})

function buildEmployeeCard(){
    $.each(arrEmployee,function(i,person){
       
            let strHTML = '<div class="card col-3 mt-5 ml-3">';
            strHTML += '<img src="images/profile.png" alt="Profile Image" style="margin:auto; max-width:100%;">';
            strHTML += '<h3 class="text-center"><a href="mailto:' + person.Email + '">' + person.FirstName + ' ' + person.LastName + '</a></h3>';
            strHTML += '<h3 class="text-center">' + person.Title +'</h3>';
            strHTML += '<h2 class="mt-2">Contact Details</h2>';
            strHTML += '<p>Phone Number: ' + person.HomePhone + '</p>';
            strHTML += '<p class="txtEmail" data-rate="' + person.Email + '">Email: ' + person.Email + '</p>';
            strHTML += '<h3 class="mt-3">Address</h3>';
            strHTML += '<p class"txtAddress" data-rate="' + person.StreetAddress1 + '">Address: ' + person.StreetAddress1 + '</p>';
            strHTML += '<p class"txtCity" data-rate="' + person.City + '">' + person.City + ', ' + person.State + '</p>';
            strHTML += '<h3 class="mt-3">Pay Details</h3>';
            strHTML += '<p class"txtPayRate" data-rate="' + person.HourlyWage + '">PayRate: ' + person.HourlyWage + '</p>';
            strHTML += '<p class"txtHoursWorked" data-rate="' + person.Hours + '">HoursWorked: ' + person.Hours + '</p>';
            strHTML += '<p class"txtTaxRate" data-rate="' + person.TaxRate + '">TaxRate: ' + person.TaxRate + '</p>';
            strHTML += '<div class="form-group mb-1">';
            strHTML += '<label class="mr-3">Goal Pay</label>';
            strHTML += '<input clas="txtGoalPay">';
            strHTML += '<button class="btn btn-primary btn-block btnGoalPay">Find Hours For Goal</button>'
            strHTML += '</div>';
            strHTML += '</div>';
            $('#divEmployeeCards').append(strHTML);
            $('#tblEmployees').append('<tr><td>' + person.FirstName + '</td><td>' + person.LastName + '</td><td>'+ person.Title +'</td><td>'+ (person.HourlyWage * person.Hours *(1-person.TaxRate)) +'</td></tr>' );
        
    });
    $('#tblEmployees').DataTable();
}

$(document).on('click','.btnCalculatePay',function(){
    let decHours = $(this).closest('.card').find('.txtHours').val();
    console.log(decHours);
    let decRate = $(this).closest('.card').find('.txtHourlyRate').text().split(': ')[1];
    console.log(decRate);
    $(this).closest('.card').find('.txtTotalPay').val(decHours * decRate);
});